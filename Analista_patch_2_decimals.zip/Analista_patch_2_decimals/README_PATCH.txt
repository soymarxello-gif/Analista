Parche: estandariza todos los números visibles a 2 decimales.

Archivos a reemplazar:
1) engine/report_engine.py
2) run_scanner.py
3) ui/dashboard.py

Qué cambia:
- CSV: números con 2 decimales.
- JSON: números redondeados a 2 decimales.
- Históricos en reports/history: números con 2 decimales.
- Salida en terminal: números con 2 decimales.
- Dashboard Streamlit: columnas numéricas con formato %.2f.
- Mantiene el manejo robusto de PermissionError si latest_scan.csv está abierto.

Instrucciones:
cd "C:\Users\El otro Yo\Projects\ChatGPT\Analista"
.\.venv\Scripts\activate
Get-ChildItem -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force
python run_scanner.py --max-candidates 50 --verbose --csv-out reports/latest_scan_2d.csv --json-out reports/latest_scan_2d.json

Luego abre:
streamlit run ui/dashboard.py

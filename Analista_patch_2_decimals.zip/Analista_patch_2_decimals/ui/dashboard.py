from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px

st.set_page_config(page_title="Analista - Swing Scanner", layout="wide")

st.title("Analista — Scanner Swing Long-Only")
st.caption("MVP 1 | Acciones comunes USA | yfinance/Yahoo Screener")

path = Path("reports/latest_scan.csv")
if not path.exists():
    st.warning("No existe reports/latest_scan.csv. Ejecuta primero: python run_scanner.py --verbose")
    st.stop()

df = pd.read_csv(path)

# Standardize numeric display to 2 decimals.
numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
for col in numeric_cols:
    df[col] = df[col].round(2)

col1, col2, col3, col4 = st.columns(4)
col1.metric("Candidatos", f"{len(df):,.0f}")
col2.metric("BUY_SETUP_ACTIVE", f"{int((df['signal'] == 'BUY_SETUP_ACTIVE').sum()):,.0f}")
col3.metric("READY_WAIT_TRIGGER", f"{int((df['signal'] == 'READY_WAIT_TRIGGER').sum()):,.0f}")
col4.metric("WATCHLIST", f"{int((df['signal'] == 'WATCHLIST').sum()):,.0f}")

signals = st.multiselect(
    "Signal",
    sorted(df["signal"].dropna().unique()),
    default=sorted(df["signal"].dropna().unique()),
)

sectors = st.multiselect(
    "Sector",
    sorted(df["sector"].dropna().unique()) if "sector" in df else [],
    default=[],
)

view = df[df["signal"].isin(signals)]
if sectors:
    view = view[view["sector"].isin(sectors)]

st.subheader("Ranking")

# Streamlit column formatting.
column_config = {}
for col in numeric_cols:
    if col in view.columns:
        column_config[col] = st.column_config.NumberColumn(col, format="%.2f")

st.dataframe(
    view,
    use_container_width=True,
    height=520,
    column_config=column_config,
)

if "signal" in df:
    st.subheader("Distribución de señales")
    fig = px.histogram(df, x="signal")
    st.plotly_chart(fig, use_container_width=True)

if "sector" in df and "final_score" in df:
    st.subheader("Score promedio por sector")
    sec = (
        df.groupby("sector", dropna=False)["final_score"]
        .mean()
        .reset_index()
        .sort_values("final_score", ascending=False)
    )
    sec["final_score"] = sec["final_score"].round(2)
    st.dataframe(
        sec,
        use_container_width=True,
        column_config={"final_score": st.column_config.NumberColumn("final_score", format="%.2f")},
    )

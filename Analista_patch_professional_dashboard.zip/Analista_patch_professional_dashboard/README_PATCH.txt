Parche: dashboard profesional + selector de archivos CSV.

Archivos a reemplazar/agregar:
1) ui/dashboard.py
2) .streamlit/config.toml

Qué incluye:
- Selector de reportes CSV desde reports/ y reports/history/.
- Botón para recargar datos y limpiar cache.
- Diseño oscuro profesional tipo terminal institucional.
- Tarjetas KPI.
- Filtros laterales por signal, setup, sector, score, R:R y búsqueda.
- Pestañas: Resumen, Oportunidades, Tabla completa, Diagnóstico.
- Gráficos: distribución de señales, score por sector, mapa Score vs R:R.
- Tabla con columnas reordenadas y todos los números a 2 decimales.
- Botón para descargar tabla filtrada.
- Diagnóstico de vetos y calidad de datos.

Instrucciones:
cd "C:\Users\El otro Yo\Projects\ChatGPT\Analista"
.\.venv\Scripts\activate
Get-ChildItem -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force
streamlit run ui/dashboard.py

Notas:
- El dashboard ya no depende solo de reports/latest_scan.csv.
- Puedes elegir latest_scan.csv, latest_scan_2d.csv, latest_scan_test*.csv o históricos.

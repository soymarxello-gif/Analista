Parche: corrige VETO masivo por liquidity_fail y limpia warnings='None'.

Archivos a modificar/reemplazar:
1) engine/scanner_engine.py
2) scoring/signal_classifier.py

Problema corregido:
- El scanner filtraba correctamente los tickers líquidos, pero no copiaba liquidity_pass a la fila final.
- signal_classifier.py recibía liquidity_pass ausente y lo trataba como False.
- Resultado: todos los tickers quedaban en VETO por liquidity_fail.

Instrucción manual si no quieres reemplazar todo scanner_engine.py:
En engine/scanner_engine.py, dentro del diccionario row = {...}, agrega esta línea cerca de liquidity_score:

"liquidity_pass": bool(m.get("liquidity_pass", False)),

Y cambia la construcción de warnings para no convertir None en texto.

Después ejecuta:
cd "C:\Users\El otro Yo\Projects\ChatGPT\Analista"
.\.venv\Scripts\activate
Get-ChildItem -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force
python run_scanner.py --max-candidates 50 --verbose --csv-out reports/latest_scan_test2.csv --json-out reports/latest_scan_test2.json

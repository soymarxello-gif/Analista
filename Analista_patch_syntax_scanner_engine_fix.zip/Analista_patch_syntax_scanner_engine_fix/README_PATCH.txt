Parche: corrige SyntaxError en engine/scanner_engine.py y conserva fix de liquidity_pass.

Archivos a reemplazar:
1) engine/scanner_engine.py
2) scoring/signal_classifier.py

Instrucciones:
1. Copia ambos archivos dentro de:
   C:\Users\El otro Yo\Projects\ChatGPT\Analista

2. Borra cache Python:
   Get-ChildItem -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force

3. Ejecuta:
   python run_scanner.py --max-candidates 50 --verbose --csv-out reports/latest_scan_test3.csv --json-out reports/latest_scan_test3.json

Resultado esperado:
- Ya no debe aparecer SyntaxError.
- La columna liquidity_pass debe existir.
- No todos los tickers deberían quedar en VETO por liquidity_fail.
- warnings ya no debería mostrar 'None'.

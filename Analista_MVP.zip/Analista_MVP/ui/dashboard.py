\
from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px

st.set_page_config(page_title="Analista - Swing Scanner", layout="wide")

st.title("Analista — Scanner Swing Long-Only")
st.caption("MVP 1 | Acciones comunes USA | yfinance/Yahoo Screener")

path = Path("reports/latest_scan.csv")
if not path.exists():
    st.warning("No existe reports/latest_scan.csv. Ejecuta primero: python run_scanner.py --verbose")
    st.stop()

df = pd.read_csv(path)

col1, col2, col3, col4 = st.columns(4)
col1.metric("Candidatos", len(df))
col2.metric("BUY_SETUP_ACTIVE", int((df["signal"] == "BUY_SETUP_ACTIVE").sum()))
col3.metric("READY_WAIT_TRIGGER", int((df["signal"] == "READY_WAIT_TRIGGER").sum()))
col4.metric("WATCHLIST", int((df["signal"] == "WATCHLIST").sum()))

signals = st.multiselect("Signal", sorted(df["signal"].dropna().unique()), default=sorted(df["signal"].dropna().unique()))
sectors = st.multiselect("Sector", sorted(df["sector"].dropna().unique()) if "sector" in df else [], default=[])

view = df[df["signal"].isin(signals)]
if sectors:
    view = view[view["sector"].isin(sectors)]

st.subheader("Ranking")
st.dataframe(view, use_container_width=True, height=520)

if "signal" in df:
    st.subheader("Distribución de señales")
    fig = px.histogram(df, x="signal")
    st.plotly_chart(fig, use_container_width=True)

if "sector" in df and "final_score" in df:
    st.subheader("Score promedio por sector")
    sec = df.groupby("sector", dropna=False)["final_score"].mean().reset_index().sort_values("final_score", ascending=False)
    st.dataframe(sec, use_container_width=True)

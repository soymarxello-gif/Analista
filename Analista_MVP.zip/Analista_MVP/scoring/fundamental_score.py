\
def score_fundamentals(meta_row, config):
    # MVP: neutral until robust fundamentals/earnings implementation.
    return {
        "fundamental_score": 0.5,
        "earnings_date": None,
        "days_to_earnings": None,
        "fundamental_warning": "fundamentales detallados no implementados en MVP",
    }

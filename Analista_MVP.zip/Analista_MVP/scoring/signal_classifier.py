\
def classify_signal(row: dict, config: dict) -> tuple[str, list[str]]:
    veto = []
    if not row.get("liquidity_pass", False):
        veto.append("liquidity_fail")
    if row.get("rr") is None or row.get("rr", 0) < config.get("risk_reward", {}).get("min_rr_absolute", 1.5):
        veto.append("rr_below_minimum")
    if row.get("trend_score", 0) < config.get("veto_rules", {}).get("thresholds", {}).get("min_trend_score", 0.55):
        veto.append("trend_score_too_weak")
    if row.get("setup_type") == "NO_VALID_SETUP":
        veto.append("no_valid_setup")

    if veto:
        return "VETO", veto

    score = row.get("final_score", 0)
    rr = row.get("rr", 0)
    trigger = row.get("trigger_confirmed", False)
    thresholds = config.get("signal_thresholds", {})

    if score >= thresholds.get("buy_setup_active", {}).get("min_score", 85) and trigger and rr >= thresholds.get("buy_setup_active", {}).get("min_rr", 2.0):
        return "BUY_SETUP_ACTIVE", []
    if score >= thresholds.get("ready_wait_trigger", {}).get("min_score", 80) and rr >= thresholds.get("ready_wait_trigger", {}).get("min_rr", 1.7):
        return "READY_WAIT_TRIGGER", []
    if score >= thresholds.get("watchlist", {}).get("min_score", 70):
        return "WATCHLIST", []
    return "AVOID", []

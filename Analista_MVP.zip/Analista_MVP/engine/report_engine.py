\
from __future__ import annotations

from pathlib import Path
from datetime import datetime
import pandas as pd


def save_reports(df: pd.DataFrame, config: dict, json_out: str | None = None, csv_out: str | None = None) -> None:
    files = config.get("outputs", {}).get("files", {})
    json_path = Path(json_out or files.get("latest_scan", "reports/latest_scan.json"))
    csv_path = Path(csv_out or files.get("latest_csv", "reports/latest_scan.csv"))
    hist_dir = Path(files.get("history_dir", "reports/history"))

    json_path.parent.mkdir(parents=True, exist_ok=True)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    hist_dir.mkdir(parents=True, exist_ok=True)

    df.to_json(json_path, orient="records", indent=2, force_ascii=False)
    df.to_csv(csv_path, index=False)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    df.to_json(hist_dir / f"scan_{stamp}.json", orient="records", indent=2, force_ascii=False)
    df.to_csv(hist_dir / f"scan_{stamp}.csv", index=False)

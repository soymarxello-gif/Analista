\
from __future__ import annotations

from loguru import logger
import pandas as pd
import numpy as np

from data.screener_client import run_screeners
from data.price_client import download_daily_prices
from universe.equity_validator import validate_universe
from universe.liquidity_filter import compute_liquidity
from indicators.pipeline import add_all_indicators
from market.market_regime import classify_market_regime
from market.sector_rotation import calculate_sector_rotation
from scoring.relative_strength import add_relative_strength_scores
from scoring.trend_score import score_trend
from scoring.volume_score import score_volume
from scoring.structure_score import score_structure
from scoring.risk_reward_score import score_risk_reward
from scoring.momentum_score import score_momentum
from scoring.fundamental_score import score_fundamentals
from scoring.final_score import calculate_final_score
from scoring.signal_classifier import classify_signal


def run_scan(config: dict, max_candidates: int | None = None) -> pd.DataFrame:
    logger.info("Iniciando scanner Analista MVP.")

    screen = run_screeners(config)
    meta = validate_universe(screen.dataframe, config)
    if max_candidates:
        meta = meta.head(max_candidates)

    tickers = meta["ticker"].dropna().astype(str).unique().tolist()
    logger.info(f"Tickers tras screener/validación: {len(tickers)}")

    price_cfg = config.get("price_data", {})
    raw_prices = download_daily_prices(
        tickers,
        period=price_cfg.get("daily_period", "1y"),
        interval=price_cfg.get("daily_interval", "1d"),
    )

    prices = {}
    liquidity_rows = []
    base_rows = []

    for t in tickers:
        df = raw_prices.get(t)
        if df is None or df.empty:
            continue
        ind = add_all_indicators(df, config)
        prices[t] = ind
        liquidity_rows.append(compute_liquidity(t, ind, config))

    liquidity = pd.DataFrame(liquidity_rows)
    if liquidity.empty:
        logger.warning("No hay datos de liquidez. Retornando DataFrame vacío.")
        return pd.DataFrame()

    meta = meta.merge(liquidity, on="ticker", how="inner")
    meta = meta[meta["liquidity_pass"] == True].reset_index(drop=True)
    tickers = meta["ticker"].tolist()
    logger.info(f"Tickers tras liquidez: {len(tickers)}")

    regime = classify_market_regime(config)
    sector_df = calculate_sector_rotation(meta, prices)
    sector_map = sector_df.set_index("ticker").to_dict(orient="index") if not sector_df.empty else {}

    # First pass: returns for percentile RS.
    for _, m in meta.iterrows():
        t = m["ticker"]
        df = prices.get(t)
        if df is None or len(df) < 64:
            continue
        ret20 = df["close"].iloc[-1] / df["close"].iloc[-21] - 1 if len(df) >= 21 else 0
        ret63 = df["close"].iloc[-1] / df["close"].iloc[-64] - 1 if len(df) >= 64 else ret20
        base_rows.append({"ticker": t, "ret20": ret20, "ret63": ret63})

    base_rows = add_relative_strength_scores(base_rows)
    rs_map = {r["ticker"]: r.get("rs_score", 0.5) for r in base_rows}

    rows = []
    for _, m in meta.iterrows():
        t = m["ticker"]
        df = prices.get(t)
        if df is None or df.empty:
            continue

        trend_score, trend_status = score_trend(df, config)
        volume_score = score_volume(df)
        structure = score_structure(df, config)
        rr_data = score_risk_reward(df, structure, config)
        momentum_score = score_momentum(df, config)
        fund = score_fundamentals(m, config)
        sector_info = sector_map.get(t, {})
        sector_score = float(sector_info.get("sector_score", 0.5) or 0.5)

        latest = df.iloc[-1]
        scores = {
            "rs_score": float(rs_map.get(t, 0.5)),
            "trend_score": trend_score,
            "market_regime_score": regime.get("regime_score_norm", 0.5),
            "volume_score": volume_score,
            "sector_score": sector_score,
            "structure_score": structure["structure_score"],
            "rr_score": rr_data["rr_score"],
            "liquidity_score": float(m.get("liquidity_score", 0.5)),
            "momentum_score": momentum_score,
            "fundamental_score": fund["fundamental_score"],
            "options_score": 0.5,
            "sentiment_score": 0.5,
        }
        final_score = calculate_final_score(scores, config)

        row = {
            "ticker": t,
            "company": m.get("company"),
            "sector": m.get("sector") or sector_info.get("sector"),
            "industry": m.get("industry"),
            "market_regime": regime.get("regime"),
            "final_score": round(final_score, 2),
            "rs_score": round(scores["rs_score"], 3),
            "trend_score": round(trend_score, 3),
            "trend_status": trend_status,
            "volume_score": round(volume_score, 3),
            "sector_score": round(sector_score, 3),
            "structure_score": round(structure["structure_score"], 3),
            "rr_score": round(rr_data["rr_score"], 3),
            "liquidity_score": round(float(m.get("liquidity_score", 0.5)), 3),
            "momentum_score": round(momentum_score, 3),
            "fundamental_score": fund["fundamental_score"],
            "setup_type": structure["setup_type"],
            "trigger_confirmed": structure["trigger_confirmed"],
            "trigger_level": structure["trigger_level"],
            "entry": rr_data["entry"],
            "stop": rr_data["stop"],
            "target": rr_data["target"],
            "rr": rr_data["rr"],
            "atr_pct": latest.get("atr_pct"),
            "relative_volume": latest.get("relative_volume"),
            "price": latest.get("close"),
            "avg_volume_20d": m.get("avg_volume_20d"),
            "dollar_volume_20d": m.get("dollar_volume_20d"),
            "earnings_date": fund.get("earnings_date"),
            "days_to_earnings": fund.get("days_to_earnings"),
            "warnings": "; ".join([str(m.get("data_quality_warning") or ""), str(m.get("liquidity_warning") or ""), fund.get("fundamental_warning", "")]).strip("; "),
        }
        signal, veto = classify_signal(row, config)
        row["signal"] = signal
        row["veto_reasons"] = ", ".join(veto)
        row["reason_summary"] = _reason_summary(row)
        rows.append(row)

    out = pd.DataFrame(rows)
    if out.empty:
        return out
    out = out.sort_values(["signal", "final_score"], ascending=[True, False])
    # Better manual signal order
    order = {"BUY_SETUP_ACTIVE": 0, "READY_WAIT_TRIGGER": 1, "WATCHLIST": 2, "AVOID": 3, "VETO": 4}
    out["_signal_order"] = out["signal"].map(order).fillna(9)
    out = out.sort_values(["_signal_order", "final_score"], ascending=[True, False]).drop(columns=["_signal_order"])
    out.insert(0, "rank", range(1, len(out) + 1))
    return out


def _reason_summary(row: dict) -> str:
    if row["signal"] == "VETO":
        return f"Veto: {row.get('veto_reasons')}"
    return (
        f"{row.get('setup_type')} | score {row.get('final_score')} | "
        f"RS {row.get('rs_score')} | trend {row.get('trend_score')} | "
        f"R:R {round(row.get('rr') or 0, 2)}"
    )

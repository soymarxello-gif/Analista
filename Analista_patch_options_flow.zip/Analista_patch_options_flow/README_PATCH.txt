Parche: implementación de métricas de opciones put/call vía yfinance.

Archivos a agregar/reemplazar:
1) data/options_client.py
2) scoring/options_score.py
3) CONFIG_FRAGMENT_OPTIONS_FLOW.yaml

También incluye notas para integrar en engine/scanner_engine.py si deseas hacerlo manualmente.

Qué agrega:
- Ticker.options y Ticker.option_chain() vía yfinance.
- Selección de vencimientos entre min_days_to_expiration y max_days_to_expiration.
- Métricas agregadas de calls/puts:
  call_volume, put_volume, call_open_interest, put_open_interest,
  put_call_volume_ratio, put_call_oi_ratio,
  call_volume_share, call_oi_share,
  near_call_open_interest, near_put_open_interest,
  near_call_oi_share,
  max_call_oi_strike, max_put_oi_strike,
  max_pain_approx,
  atm_implied_volatility,
  total_option_volume, total_option_open_interest.
- options_score 0-1.
- options_bias: BULLISH / NEUTRAL / BEARISH.
- options_confidence: HIGH / MEDIUM / LOW.
- warning contrarian si el put/call es extremadamente bajo.

Importante:
- Opciones se usan solo como confirmación de flujo, no como activo operable.
- Si no hay datos de opciones, options_score queda neutral en 0.50.
- Activa options_flow en config.yaml copiando el fragmento CONFIG_FRAGMENT_OPTIONS_FLOW.yaml.
- Empieza con max_tickers_per_run: 20 o 50, porque option_chain es lento.

Prueba después de integrar scanner_engine:
python run_scanner.py --max-candidates 30 --verbose --csv-out reports/latest_scan_options.csv --json-out reports/latest_scan_options.json
